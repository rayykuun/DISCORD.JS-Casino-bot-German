const { ClientPresence } = require("discord.js");

module.exports = (client) => {
  console.log(`[UPDATE] ${client.user.username} is now Starting!`);

  console.log(
    `[UPDATE] ${client.user.username} is now in ${client.guilds.cache.size} servers!`
  );
  console.log(`[UPDATE] ${client.user.username} is now online!`);
};
