const { EmbedBuilder } = require("discord.js");

module.exports = (message) => {
  if (message.author.bot) return;

  if (message.content === "hi") {
    message.reply("Hello!");
  } else if (message.content === "!help") {
    const embed = new EmbedBuilder()
      .setTitle("Help")
      .setDescription("use command /help to recieve a list of commands");
    message.reply({ embeds: [embed] });
  }
};
