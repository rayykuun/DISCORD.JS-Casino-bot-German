const { EmbedBuilder } = require("discord.js"); // Make sure to import EmbedBuilder

module.exports = {
  data: {
    name: "ping",
    description: "Reply with pong and latency information!",
  },

  run: async ({ interaction }) => {
    // Send a preliminary message
    const sent = await interaction.reply({
      content: "Pinging...",
      fetchReply: true,
    });

    // Calculate the round-trip latency
    const roundTripLatency =
      sent.createdTimestamp - interaction.createdTimestamp;

    // Calculate the API latency
    const apiLatency = Math.round(interaction.client.ws.ping);

    // Create an embed with the latency information using EmbedBuilder
    const embed = new EmbedBuilder()
      .setTitle("🏓 Pong!")
      .setDescription(
        `Bot Latency: ${roundTripLatency}ms\nAPI Latency: ${apiLatency}ms`
      )
      .setColor(0x00ae86); // You can set a specific color if you prefer

    // Edit the original message with the latency information
    await interaction.editReply({ content: null, embeds: [embed] });
  },
};

// delete any command with 1 line of code:           deleted: true,
