const RoleBonus = require("../../../schemas/RoleBonus");
const { EmbedBuilder } = require("discord.js");

module.exports = {
  run: async ({ interaction }) => {
    const roleId = interaction.options.getString("role");
    const bonusAmount = interaction.options.getInteger("amount");

    try {
      // Überprüfen, ob der Bonus für die Rolle bereits existiert
      let roleBonus = await RoleBonus.findOne({ roleId });
      if (roleBonus) {
        // Aktualisiere den vorhandenen Eintrag
        roleBonus.bonusAmount = bonusAmount;
      } else {
        // Erstelle einen neuen Eintrag
        roleBonus = new RoleBonus({
          roleId,
          bonusAmount,
        });
      }

      await roleBonus.save();
      const embed = new EmbedBuilder()
        .setColor(0xffff00) // Grün für Erfolgsmeldungen
        .setTitle("Erfolgreich")
        .setDescription(`Bonus für <@&${roleId}> gesetzt: ${bonusAmount}`);

      interaction.reply({ embeds: [embed] });
    } catch (error) {
      if (error instanceof DiscordAPIError) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000) // Rot für Fehlermeldungen
          .setTitle("Fehler aufgetreten")
          .setDescription(
            "Beim Ausführen des Befehls ist ein Fehler aufgetreten."
          )
          .addFields(
            { name: "Fehlermeldung", value: error.message },
            { name: "Fehlercode", value: error.code.toString() }
            // Fügen Sie hier weitere relevante Informationen hinzu
          );

        // Senden Sie das Embed als Antwort auf eine Interaktion
        interaction.reply({ embeds: [embed] });
      } else {
        // Behandeln Sie andere Arten von Fehlern
        console.error("Ein unerwarteter Fehler ist aufgetreten:", error);
      }
    }
  },

  data: {
    name: "setrolebonus",
    description: "Setzt den täglichen Bonus für eine Rolle",
    type: 1, // 1 steht für CHAT_INPUT (Slash-Befehl)
    options: [
      {
        type: 3, // 3 steht für STRING
        name: "role",
        description: "Die ID der Rolle",
        required: true,
      },
      {
        type: 4, // 4 steht für INTEGER
        name: "amount",
        description: "Der Bonusbetrag",
        required: true,
      },
    ],
  },
};
