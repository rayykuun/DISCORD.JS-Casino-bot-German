const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../../schemas/UserProfile");
const CooldownSchema = require("../../../schemas/Cooldown");

module.exports = {
  data: {
    name: "overview",
    description: "Bekomme eine übersicht über alle Daten eines Users",
    options: [
      {
        name: "user",
        description: "der user der du anzeigen möchtest",
        type: 6, // User type
        required: true,
      },
    ],
  },

  run: async ({ interaction }) => {
    try {
      await interaction.deferReply();

      const target = interaction.options.getUser("user");
      const targetId = target.id;

      const userProfile = await UserProfileSchema.findOne({
        userid: targetId,
      });

      const cooldowns = await CooldownSchema.find({
        userid: targetId,
      });

      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle(`${target.username}'s Overview`);

      if (userProfile) {
        // Add user profile data to the embed
        embed.addFields(
          { name: "Balance", value: `${userProfile.balance}`, inline: true },
          {
            name: "Chicken HP",
            value: `${userProfile.chickenhp}`,
            inline: true,
          },
          {
            name: "Win Chance",
            value: `${userProfile.winChance}%`,
            inline: true,
          }
        );
      } else {
        embed.addFields({
          name: "Profile",
          value: "Kein Pfrofil gefunden.",
          inline: true,
        });
      }

      if (cooldowns.length > 0) {
        // Add cooldown data to the embed
        cooldowns.forEach((cooldown) => {
          const timeLeft = cooldown.endsAt - new Date();
          if (timeLeft > 0) {
            const minutes = Math.floor(timeLeft / (1000 * 60))
              .toString()
              .padStart(2, "0");
            const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000)
              .toString()
              .padStart(2, "0");
            embed.addFields({
              name: `${cooldown.commandname} Cooldown`,
              value: `Time left: ${minutes}:${seconds}`,
              inline: true,
            });
          }
        });
      } else {
        embed.addFields({
          name: "Cooldowns",
          value: "keine Cooldowns gefunden.",
          inline: true,
        });
      }

      return await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("Error running overview command", error);

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription("es ist ein Fehler aufgetreten.");

      return await interaction.editReply({ embeds: [embed] });
    }
  },
};
