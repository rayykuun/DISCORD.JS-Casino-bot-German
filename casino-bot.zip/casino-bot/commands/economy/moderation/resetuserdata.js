const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const UserProfileSchema = require("../../../schemas/UserProfile");
const CooldownSchema = require("../../../schemas/Cooldown");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("resetuserdata")
    .setDescription("Reset alle Datas von dem user.")
    .addUserOption((option) =>
      option.setName("user").setDescription("Der user").setRequired(true)
    ),

  run: async ({ interaction }) => {
    try {
      await interaction.deferReply({ ephemeral: true });

      const target = interaction.options.getUser("user");
      const targetId = target.id;

      // Reset UserProfile data
      await UserProfileSchema.findOneAndUpdate(
        { userid: targetId },
        { balance: 0, lastDailyCollect: new Date(0) }, // Set default values
        { upsert: true, new: true }
      );

      // Reset Cooldown data
      await CooldownSchema.deleteMany({ userid: targetId });

      // Send confirmation message
      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setDescription(
          `Gesammte data für: ${target.username} wurde geresettet.`
        );

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("Error running resetuserdata command", error);

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription("es ist ein Fehler aufgetreten.");

      await interaction.editReply({ embeds: [embed] });
    }
  },
};
