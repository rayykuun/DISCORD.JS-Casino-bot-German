const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const UserProfile = require("../../../schemas/UserProfile");
const Cooldown = require("../../../schemas/Cooldown");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("moderation")
    .setDescription("Moderiere von einem user Stats")
    .addStringOption((option) =>
      option
        .setName("userid")
        .setDescription("Die id des Users")
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName("field")
        .setDescription("was soll geändert werden?")
        .setRequired(true)
        .addChoices(
          {
            name: "balance",
            value: "balance",
          },
          {
            name: "chickenhp",
            value: "chickenhp",
          },
          {
            name: "winChance",
            value: "winChance",
          },
          {
            name: "horseName",
            value: "horseName",
          },
          {
            name: "horseStamina",
            value: "horseStamina",
          },
          {
            name: "horseUpgrade",
            value: "horseUpgrade",
          }
        )
    )
    .addNumberOption((option) =>
      option.setName("value").setDescription("Die neue Value").setRequired(true)
    ),

  run: async ({ interaction }) => {
    const userid = interaction.options.getString("userid");
    const field = interaction.options.getString("field");
    const value = interaction.options.getNumber("value");

    try {
      const user = await UserProfile.findOneAndUpdate(
        { userid: userid },
        { [field]: value }
      );

      if (!user) {
        return interaction.reply("user nicht gefunden!");
      }

      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setDescription(
          `- **Field:** ${field} \n- **User:** <@${userid}> \n- **set to:** ${value}`
        )
        .setFooter({ text: `Moderiert von: ${interaction.user.tag}` });

      interaction.reply({ embeds: [embed] });
      console.log(`${interaction.user.tag} changed ${field} to ${value}`);
    } catch (err) {
      console.error(err);
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription("Ein Fehler ist aufgetreten!")
        .setFooter({ text: `Requested by ${interaction.user.tag}` });
      interaction.reply({ embeds: [embed] });
    }
  },
};
