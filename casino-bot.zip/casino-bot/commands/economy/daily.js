const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../schemas/UserProfile");
const CooldownSchema = require("../../schemas/Cooldown");
const RoleBonusSchema = require("../../schemas/RoleBonus");

const dailyAmount = 50;
const msInADay = 24 * 60 * 60 * 1000;

module.exports = {
  deleted: true,
  run: async ({ interaction }) => {
    const currentDate = new Date();
    if (!interaction.inGuild()) {
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription("This Command has to be used in a Server.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
    try {
      await interaction.deferReply();
      let user = await UserProfileSchema.findOne({
        userid: interaction.member.id,
      });
      let cooldown = await CooldownSchema.findOne({
        userid: interaction.member.id,
        commandname: "daily",
      });
      if (!cooldown) {
        cooldown = new CooldownSchema({
          userid: interaction.member.id,
          commandname: "daily",
          endsAt: new Date(currentDate.getTime() + msInADay),
        });
      } else {
        if (currentDate < cooldown.endsAt) {
          const timeLeft = cooldown.endsAt - currentDate;
          const minutes = Math.floor(timeLeft / (1000 * 60))
            .toString()
            .padStart(2, "0");
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000)
            .toString()
            .padStart(2, "0");

          const embed = new EmbedBuilder()
            .setColor(0xffff00)
            .setDescription(
              `You have already collected your daily reward. You can collect again in ${minutes}:${seconds}.`
            );

          return interaction.editReply({ embeds: [embed] });
        } else {
          cooldown.endsAt = new Date(currentDate.getTime() + msInADay);
        }
      }

      await cooldown.save();

      let roleBonus = await RoleBonusSchema.findOne({
        roleId: interaction.member.roles.cache.map((role) => role.id),
      });

      let bonus = 0;
      if (roleBonus) {
        bonus = roleBonus.bonus;
      }

      user.balance += dailyAmount + bonus;
      user.lastDaily = currentDate;
      await user.save();

      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setDescription(
          `You collected your daily reward of ${dailyAmount}!${
            bonus > 0 ? ` Plus a bonus of ${bonus} for your roles.` : ""
          }\nNew Balance: ${user.balance}`
        );

      interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(
        "There was an error while running the Daily command: ",
        error
      );

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "An error occurred while running the command.\nPlease contact the developer."
        );

      interaction.editReply({ embeds: [embed] });
    }
  },

  data: {
    name: "daily",
    description: "Collect your daily reward",
  },
};
