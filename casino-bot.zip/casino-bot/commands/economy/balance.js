const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../schemas/UserProfile");
const CooldownSchema = require("../../schemas/Cooldown");

module.exports = {
  data: {
    name: "balance",
    description: "Checke deine Stats oder die von anderen",
    options: [
      {
        name: "user",
        description:
          "wähle hier den user von dem du die Balance sehen möchtest",
        type: 6, // User type
        required: false,
      },
    ],
  },

  run: async ({ interaction }) => {
    try {
      await interaction.deferReply();

      const target = interaction.options.getUser("user") || interaction.user;
      const targetId = target.id;

      const userProfile = await UserProfileSchema.findOne({
        userid: targetId,
      });

      if (!userProfile) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription(`Kein Profiel gefunden für: ${target.username}.`);

        return await interaction.editReply({ embeds: [embed] });
      }

      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle(`${target.username}'s Profile`);

      embed.addFields({
        name: "Guthaben:",
        value: `${userProfile.balance}`,
        inline: false,
      });

      // Daily cooldown

      const currentDate = new Date();
      const timeSinceLastCollect = currentDate - userProfile.lastDailyCollect;

      // Cooldowns from schema

      const cooldowns = await CooldownSchema.find({
        userid: targetId,
      });

      for (const cooldown of cooldowns) {
        const currentDate = new Date();
        const timeLeft = cooldown.endsAt - currentDate;

        if (timeLeft > 0) {
          const minutes = Math.floor(timeLeft / (1000 * 60))
            .toString()
            .padStart(2, "0");

          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000)
            .toString()
            .padStart(2, "0");

          embed.addFields({
            name: cooldown.commandname,
            value: `Time left: ${minutes}:${seconds}`,
            inline: true,
          });
        }
      }

      return await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("Error running balance command", error);

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "Da ist leider ein fehler passiert.\nbitte wende dich an rayykuun."
        );

      return await interaction.editReply({ embeds: [embed] });
    }
  },
};
