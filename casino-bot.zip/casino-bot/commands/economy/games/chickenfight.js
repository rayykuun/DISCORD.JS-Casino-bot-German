const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../../schemas/UserProfile");

module.exports = {
  run: async ({ interaction }) => {
    const betAmount = interaction.options.getInteger("amount");

    try {
      await interaction.deferReply();

      const user = await UserProfileSchema.findOne({
        userid: interaction.member.id,
      });

      if (!user) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription("Du hast kein profil um diesen Command zu nutzen.");

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      if (user.chickenhp <= 0) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription(
            "du hast kein chicken um diesen Command zu nutzen.\nkauf eins mit dem command /buychicken"
          );

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      if (user.balance < betAmount) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription(
            "Du hast nicht genug guthaben um diesen Command zu nutzen.\noder du hast mehr gesetzt als du hast\ndein guthaben:" +
              user.balance
          );

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      const winChance = user.winChance || 50; // Default win chance is 50%
      const didWin = Math.random() * 100 < winChance;
      let resultMessage;

      if (didWin) {
        user.balance += betAmount; // Add the bet amount to the user's balance
        user.winChance = (user.winChance || 50) + 2;
        resultMessage = `Herzlichen Glückwunsch! \nDein Chicken hat gewonnen.\ndu hast ${betAmount} Gewonnen!`;
      } else {
        user.balance -= betAmount; // Subtract the bet amount from the user's balance
        user.chickenhp -= 1; // Decrease chickenhp by 1
        user.winChance = 50;
        resultMessage = `Oh Nein! \nDein Chicken hat den kampf verloren!\n Du hast ${betAmount} Verloren.\n\n**Deine Neuen Stats:**`;
      }

      await user.save(); // Save the changes to the database

      const embed = new EmbedBuilder()
        .setColor(didWin ? 0x00ff00 : 0xff0000)
        .setDescription(
          resultMessage +
            `\nNeue Win Chance: ${user.winChance}\nNeues Guthaben: ${user.balance}`
        );

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(
        "There was an error while running the chickenfight command: ",
        error
      );

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "Da ist leider ein fehler passiert.\nbitte wende dich an rayykuun."
        );

      await interaction.editReply({ embeds: [embed] });
    }
  },

  data: {
    name: "chickenfight",
    description: "Sende dein Chicken zum Kampf",
    options: [
      {
        type: 4, // INTEGER type
        name: "amount",
        description: "Wieviel möchtest du auf dein chicken setzen?",
        required: true,
      },
    ],
  },
};
