const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../../schemas/UserProfile");

module.exports = {
  run: async ({ interaction }) => {
    const chickenPrice = 50; // Set the price for a new chicken

    try {
      await interaction.deferReply();

      const user = await UserProfileSchema.findOne({
        userid: interaction.member.id,
      });

      if (!user) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription("Du hast kein Profil um ein Chicken zu kaufen.");

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      if (user.balance < chickenPrice) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription("du hast nicht genug Geld um ein Chicken zu kaufen.");

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      if (user.chickenhp > 0) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription("Du hast bereits ein chicken.");

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      // Logic for buying a chicken
      user.balance -= chickenPrice; // Subtract the chicken price from the user's balance
      user.chickenhp = 1; // Set the chicken HP to a starting value, for example 10

      await user.save(); // Save the changes to the database

      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setDescription(
          `Du hast erfolgreich ein chicken gekauft für: ${chickenPrice}! dein neues Guthaben ist: ${user.balance}.`
        );

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(
        "There was an error while running the buychicken command: ",
        error
      );

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "da ist leider ein fehler aufgetreten.\nBitte wende dich an rayykuun."
        );

      await interaction.editReply({ embeds: [embed] });
    }
  },

  data: {
    name: "buychicken",
    description: "kauf ein chicken um an chickenfights teilzunehmen",
  },
};
