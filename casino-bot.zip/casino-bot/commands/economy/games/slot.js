const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../../schemas/UserProfile");

module.exports = {
  run: async ({ interaction }) => {
    const betAmount = interaction.options.getInteger("amount");

    if (betAmount < 10) {
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription("Der Mindestbetrag wo man Setzen kann ist 10.");

      interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    try {
      await interaction.deferReply();

      const user = await UserProfileSchema.findOne({
        userid: interaction.member.id,
      });

      if (!user || user.balance < betAmount) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription(
            "Du hast nicht genug geld um diese wette zu plazieren."
          );

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      // Slot-Logik mit drei Reihen, die nacheinander generiert werden
      const slotValues = ["🍒", "🍋", "🔔", "💎", "7️⃣"];
      const slotRows = [[], [], []];
      let displayRows = ["", "", ""];

      // Generiere jede Reihe einzeln und zeige sie nacheinander an
      for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
          slotRows[i].push(
            slotValues[Math.floor(Math.random() * slotValues.length)]
          );
          displayRows[i] += slotRows[i][j] + " ";
        }
        if (i === 1) {
          displayRows[i] += "| ⏪";
        }

        // Zeige die aktuelle Reihe an
        const currentRowEmbed = new EmbedBuilder()
          .setColor(0xffff00)
          .setDescription(`Spinning... 🎰\n${displayRows.join("\n")}`);
        await interaction.editReply({ embeds: [currentRowEmbed] });

        // Optional: Verzögerung zwischen den Reihen, wenn gewünscht
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }

      let didWin = false;
      let multiplier = 0;

      // Nur die mittlere Reihe zählt für die Gewinnkombination
      const middleRow = slotRows[1];
      if (middleRow[0] === middleRow[1] && middleRow[1] === middleRow[2]) {
        didWin = true;
        multiplier = 5; // Gewinnmultiplikator für drei gleiche Symbole in der mittleren Reihe
      }

      let resultMessage;
      if (didWin) {
        const winnings = betAmount * multiplier;
        user.balance += winnings;
        resultMessage = `HERZLICHEN GLÜCKWUNSCH! 🎰\n${slotRows
          .map((row, index) => row.join(" ") + (index === 1 ? " | ⏪" : ""))
          .join("\n")} \nDu hast: ${winnings} gewonnen!`;
      } else {
        user.balance -= betAmount;
        resultMessage = `ERGEBNIS: 🎰\n${slotRows
          .map((row, index) => row.join(" ") + (index === 1 ? " | ⏪" : ""))
          .join("\n")} \nYou lost ${betAmount}. \nviel glück nächstes mal!`;
      }

      await user.save();

      const embed = new EmbedBuilder()
        .setColor(didWin ? 0x00ff00 : 0xff0000)
        .setDescription(resultMessage + `\nNeues Guthaben: ${user.balance}`);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(
        "There was an error while running the Slot command: ",
        error
      );

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "Da ist leider ein fehler passiert.\nbitte wende dich an rayykuun."
        );

      await interaction.editReply({ embeds: [embed] });
    }
  },

  data: {
    name: "slot",
    description: "spiel ein Slot game",
    options: [
      {
        type: 4, // INTEGER type
        name: "amount",
        description: "Wieviel möchtest du setzten ?",
        required: true,
      },
    ],
  },
};
