const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../../schemas/UserProfile");

module.exports = {
  run: async ({ interaction }) => {
    const betAmount = interaction.options.getInteger("amount");
    const betType = interaction.options.getString("type");
    const betValue = interaction.options.getString("value");

    if (betAmount < 10) {
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription("Du must mindestens 10 Setzten.");

      interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    try {
      await interaction.deferReply();

      const user = await UserProfileSchema.findOne({
        userid: interaction.member.id,
      });

      if (!user || user.balance < betAmount) {
        const embed = new EmbedBuilder()
          .setColor(0xff0000)
          .setDescription(
            "Du hast nicht genug guthaben um diese wette zu plazieren.\ndein guthaben:" +
              user.balance
          );

        await interaction.editReply({ embeds: [embed] });
        return;
      }

      // Roulette-Logik
      const rouletteResult = Math.floor(Math.random() * 37); // 0-36 für europäisches Roulette
      const colors = ["red", "black"];
      const winningColor = colors[rouletteResult % 2]; // Einfache Annahme: Gerade Zahlen sind rot, ungerade sind schwarz

      let didWin = false;
      let multiplier = 0;

      switch (betType) {
        case "number":
          if (rouletteResult === parseInt(betValue)) {
            didWin = true;
            multiplier = 35; // Gewinn bei einer Zahl ist 35:1
          }
          break;
        case "color":
          if (winningColor === betValue) {
            didWin = true;
            multiplier = 2; // Gewinn bei einer Farbe ist 1:1
          }
          break;
        // Weitere Wettoptionen können hier hinzugefügt werden
      }

      let resultMessage;
      if (didWin) {
        const winnings = betAmount * multiplier;
        user.balance += winnings;
        resultMessage = `**HERZLICHEN GLÜCKWUNSCH!** \n\nDer Ball landete auf: ${rouletteResult} (${winningColor}). \nDu hast gewonnen: ${winnings}!`;
      } else {
        user.balance -= betAmount;
        resultMessage = `Der Ball landete auf: ${rouletteResult} (${winningColor}). \nDu hast: ${betAmount} verloren.!`;
      }

      await user.save();

      const embed = new EmbedBuilder()
        .setColor(didWin ? 0x00ff00 : 0xff0000)
        .setDescription(resultMessage + `\nNeues Guthaben: ${user.balance}`);

      await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(
        "There was an error while running the Roulette command: ",
        error
      );

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "Da ist leider ein fehler passiert.\nbitte wende dich an rayykuun."
        );

      await interaction.editReply({ embeds: [embed] });
    }
  },

  data: {
    name: "roulette",
    description: "Spiel ein Roulette game",
    options: [
      {
        type: 4, // INTEGER type
        name: "amount",
        description: "Die menge die du setzen möchtest",
        required: true,
      },
      {
        type: 3, // STRING type
        name: "type",
        description: "auf was möchtest du setzten ? (number oder color)",
        required: true,
        choices: [
          { name: "number", value: "number" },
          { name: "color", value: "color" },
        ],
      },
      {
        type: 3, // STRING type
        name: "value",
        description:
          "die Value die du setzen möchtest (für number 1-37) oder die Farbe (red, black)",
        required: true,
      },
    ],
  },
};
