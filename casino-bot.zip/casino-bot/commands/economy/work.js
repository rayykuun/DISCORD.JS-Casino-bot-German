const { EmbedBuilder } = require("discord.js");
const UserProfileSchema = require("../../schemas/UserProfile");
const CooldownSchema = require("../../schemas/Cooldown");

const workAmount = 100;
const msInAnHour = 60 * 60 * 1000;

module.exports = {
  run: async ({ interaction }) => {
    const currentDate = new Date();

    if (!interaction.inGuild()) {
      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription("This Command has to be used in a Server.");

      interaction.reply({ embeds: [embed], ephemeral: true });
      console.log(
        `${interaction.member.user.tag} tried to use the Command: ${interaction.name} in DMs.`
      );
      return;
    }

    try {
      await interaction.deferReply();

      let user = await UserProfileSchema.findOne({
        userid: interaction.member.id,
      });

      let cooldown = await CooldownSchema.findOne({
        userid: interaction.member.id,
        commandname: "work",
      });

      if (!cooldown) {
        cooldown = new CooldownSchema({
          userid: interaction.member.id,
          commandname: "work",
          endsAt: new Date(currentDate.getTime() + msInAnHour),
        });
      } else {
        if (currentDate < cooldown.endsAt) {
          const timeLeft = cooldown.endsAt - currentDate;
          const minutes = Math.floor(timeLeft / (1000 * 60))
            .toString()
            .padStart(2, "0");
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000)
            .toString()
            .padStart(2, "0");

          const embed = new EmbedBuilder()
            .setColor(0xffff00)
            .setDescription(
              `Du hast bereitsgearbeitet. du kannst wieder in ${minutes}:${seconds} Arbeiten.`
            );

          await interaction.editReply({ embeds: [embed] });
          return;
        } else {
          cooldown.endsAt = new Date(currentDate.getTime() + msInAnHour);
        }
      }
      await cooldown.save();

      user.balance += workAmount;
      user.lastWorkCollected = currentDate;
      await user.save();

      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setDescription(
          `You worked and earned ${workAmount}!\nNew Balance: ${user.balance}`
        );

      interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error(
        "There was an error while running the Work command: ",
        error
      );

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "Da ist leider ein fehler passiert.\nbitte wende dich an rayykuun."
        );

      interaction.editReply({ embeds: [embed] });
    }
  },

  data: {
    name: "work",
    description: "Arbeite um geld zu verdienen",
  },
};
