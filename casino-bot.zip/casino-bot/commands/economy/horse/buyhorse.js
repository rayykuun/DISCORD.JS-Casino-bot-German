const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const UserProfile = require("../../../schemas/UserProfile");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("buyhorse")
    .setDescription(
      "Kaufe ein Horse für 1000 Coins. Du kannst nur einen Horse kaufen."
    )
    .addStringOption((option) =>
      option
        .setName("name")
        .setDescription("Gebe ein Namen für den Horse ein.")
        .setRequired(true)
    ),

  run: async ({ interaction }) => {
    const name = interaction.options.getString("name");

    const user = await UserProfile.findOne({ userid: interaction.user.id });
    if (!user.horseName === "None") {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setDescription("Du hast bereits einen Horse!")
            .setColor("#ff0000"),
        ],
      });
    }

    if (user.balance < 1000) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("#ff0000")
            .setDescription(
              "du hast nicht genug Geld um einen Horse zu kaufen.\n ein Horse kostet 1000 Coins."
            ),
        ],
      });
    }

    user.horseName = name;
    user.horseStamina = 10;
    user.horseUpgrade = 0;

    user.balance -= 1000;

    await user.save();

    const embed = new EmbedBuilder()
      .setColor("#00ff00")
      .setTitle("Horse Gekauft")
      .setDescription(
        `Du hast ein horse gekauft und hast es: ${name} genannt!\n- Standart horse Stamina: ${user.horseStamina}\n`
      );

    return interaction.reply({ embeds: [embed] });
  },
};
