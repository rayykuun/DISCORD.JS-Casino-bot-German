const {
  CommandInteraction,
  SlashCommandBuilder,
  EmbedBuilder,
} = require("discord.js");
const UserProfile = require("../../../schemas/UserProfile");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("upgradehorse")
    .setDescription("Upgrade dein Horse mit upgradepoints"),

  run: async ({ interaction }) => {
    const user = await UserProfile.findOne({
      userid: interaction.user.id,
    });

    if (user.horseUpgrade < 1) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder().setDescription("Du hast keine Upgradepoints!"),
        ],
      });
    }

    user.horseStamina += 2;
    user.horseUpgrade--;

    await user.save();

    return interaction.reply({
      embeds: [
        new EmbedBuilder().setDescription(
          `Stamina erfolgreich geupgradet um 2. übrige upgrade points: ${user.horseUpgrade}`
        ),
      ],
    });
  },
};
