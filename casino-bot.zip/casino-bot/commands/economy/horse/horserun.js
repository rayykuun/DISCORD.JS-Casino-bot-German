const {
  CommandInteraction,
  SlashCommandBuilder,
  EmbedBuilder,
} = require("discord.js");
const UserProfile = require("../../../schemas/UserProfile.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("horserun")
    .setDescription("Schicke dein Horse auf ein Rennen"),

  run: async ({ interaction }) => {
    cooldowns.set(interaction.user.id, Date.now() + cooldownAmount);
    try {
      const userId = interaction.user.id;

      const userProfile = await UserProfile.findOne({ userid: userId });

      if (!userProfile) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder().setDescription(
              "es ist ein Fehler passiert.\nhast du ein horse? hast du schon andere commands genutzt?"
            ),
          ],
        });
      }

      if (userProfile.horseName === "None") {
        return interaction.reply({
          embeds: [new EmbedBuilder().setDescription("Du hast kein Horse!")],
        });
      }

      const raceResult = Math.random() * 60 < userProfile.horseStamina;
      const prize = Math.floor(Math.random() * 500) + 100;

      if (raceResult) {
        userProfile.balance += prize;

        if (Math.random() < 0.05) {
          upgradeHorse(userProfile);
        }

        await userProfile.save();

        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("#00ff00")
              .setTitle("Horse Race")
              .setDescription(
                `Du hast Gewonnen! dein Preis: ${prize}!\nDeine Pferde Stamina ist: ${userProfile.horseStamina}.\nDu hast: ${userProfile.horseUpgrade} Upgrade Points.`
              )
              .setFooter({
                text: "es gibt eine 0,5% chance auf ein upgrade point.",
              }),
          ],
        });
      } else {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setDescription("Du hast Verloren!")
              .setColor("#ff0000"),
          ],
        });
      }
    } catch (err) {
      console.error(err);
      return interaction.reply({
        embeds: [
          new EmbedBuilder().setDescription("es ist ein Fehler aufgetreten."),
        ],
      });
    }

    function upgradeHorse(profile) {
      profile.horseUpgrade++;
    }
  },
};
