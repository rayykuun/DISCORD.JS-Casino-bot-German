const { EmbedBuilder } = require("discord.js");

module.exports = {
  data: {
    name: "help",
    description: "zeige alle Commands an",
    options: [],
  },

  run: async ({ interaction }) => {
    try {
      await interaction.deferReply();

      const embed = new EmbedBuilder()
        .setColor(0x00ff00)
        .setTitle("Alle Commands:")
        .addFields(
          {
            name: "Verdiene Geld",
            value: "/work \n/daily",
            inline: false,
          },
          {
            name: "-------- GAMES -------- ",
            value: " ",
            inline: false,
          },
          {
            name: "Horse Race",
            value: "/buyhorse \n/horserun \n/upgradehorse",
            inline: true,
          },
          {
            name: "CHICKENFIGHT",
            value: "/buychicken \n/chickenfight",
            inline: true,
          },
          {
            name: "CASINO GAMES",
            value: "/slot \n/roulette \n more comming soon",
            inline: true,
          }
        );

      return await interaction.editReply({ embeds: [embed] });
    } catch (error) {
      console.error("Error running help command", error);

      const embed = new EmbedBuilder()
        .setColor(0xff0000)
        .setDescription(
          "Da ist leider ein fehler passiert.\nbitte wende dich an rayykuun."
        );

      return await interaction.editReply({ embeds: [embed] });
    }
  },
};
