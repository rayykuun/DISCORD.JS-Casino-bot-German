const mongoose = require("mongoose");

const RoleBonusSchema = new mongoose.Schema({
  roleId: {
    type: String,
    required: true,
    unique: true,
  },
  bonusAmount: {
    type: Number,
    required: true,
  },
});

module.exports = mongoose.model("RoleBonus", RoleBonusSchema);
