const { Schema, model } = require("mongoose");

const cooldownSchema = new Schema({
  commandname: {
    type: String,
    required: true,
  },
  userid: {
    type: String,
    required: true,
  },
  endsAt: {
    type: Date,
    required: true,
  },
});

module.exports = model("cooldown", cooldownSchema);
