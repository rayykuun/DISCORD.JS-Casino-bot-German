const { Schema, model } = require("mongoose");

const userProfileSchema = new Schema(
  {
    userid: {
      type: String,
      required: true,
    },
    balance: {
      type: Number,
      default: 0,
    },
    chickenhp: {
      type: Number,
      default: 0,
    },
    winChance: {
      type: Number,
      default: 50,
    },
    horseName: {
      type: String,
      default: "None",
    },
    horseStamina: {
      type: Number,
      default: 20,
    },
    horseUpgrade: {
      type: Number,
      default: 0,
    },
  },
  { timestamps: true }
);

module.exports = model("userProfile", userProfileSchema);
