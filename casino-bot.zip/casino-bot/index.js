require("dotenv").config();
const fs = require("node:fs");
const path = require("node:path");
const { CommandHandler } = require("djs-commander");
const { DISCORD_TOKEN: token, PREFIX: prefix } = process.env;
const mongoose = require("mongoose");
const { Client, GatewayIntentBits } = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
  ],
});

new CommandHandler({
  client,
  eventsPath: path.join(__dirname, "events"),
  commandsPath: path.join(__dirname, "commands"),
  prefix: prefix,
});

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log("[UPDATE] Connected to MongoDB");

  client.login(token);
})();
